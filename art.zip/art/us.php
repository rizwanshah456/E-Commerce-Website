<?php

$BC=@mysqli_connect('localhost','root','','art') or die('you are not upto the level');

$value1=$_POST['name'];
$value2=$_POST['email'];
$value3=$_POST['phone'];
$value4=$_POST['message'];



$sql="INSERT INTO contact(name,email,phone,message) VALUES('$value1','$value2','$value3','$value4')";


if(!mysqli_query($BC,$sql))
{
  die('not working'.mysqli_error($BC));

}
 mysqli_close($BC);
 
 echo ("<script LANGUAGE='JavaScript'>
    window.alert('Successfully ..!');
    window.location.href='index.html';
    </script>");

?>
