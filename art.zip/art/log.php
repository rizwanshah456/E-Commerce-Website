<?php
$servername='localhost';
$username='root';
$password='';
$database='art';
$con=mysqli_connect($servername,$username,$password,$database);
$email=$_POST['email'];
$pass=$_POST['pass'];

$sql="SELECT * FROM sign_up WHERE email='$email' AND pass='$pass'";
$res=mysqli_query($con,$sql);

if(mysqli_num_rows($res)==1)
{
header('location:index.html');
exit();
}
else
{
  echo ("<script LANGUAGE='JavaScript'>
      window.alert('Invalid Login.');
     window.location.href='index.html';
      </script>");
exit();
}
?>
